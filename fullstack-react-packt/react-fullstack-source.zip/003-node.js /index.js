/*const server = require('http').createServer((req,res) => {
	var isarray = require('isarray'),
		a = [20,10,32],
		s = "I'm not an array",
		out = 'Hello World From Node.js<hr/>';
		out+= "is 'a' an array?",isarray(a) +"<br/>",
					"is 's' an array?",isarray(s) +"<br/>";

	res.statusCode = 200;
	res.setHeader('Content-Type','text/plain');

	res.end(out);
});

server.listen(3001,'127.0.0.1',() => {
	console.log("I'm running!");
});*/



